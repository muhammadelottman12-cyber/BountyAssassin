package me.bountyassassin;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Bounty Assassin Event - main plugin class. Wires all services together.
 */
public final class BountyPlugin extends JavaPlugin {

    private Settings settings;
    private Messages messages;
    private TrackingService tracking;
    private BossBarService bossBars;
    private IndicatorService indicator;
    private EventManager events;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.settings = new Settings(getConfig());
        this.messages = new Messages(this);
        this.tracking = new TrackingService();
        this.bossBars = new BossBarService(this);
        this.indicator = new IndicatorService(this);
        this.events = new EventManager(this);

        BountyCommand command = new BountyCommand(this);
        PluginCommand pluginCommand = getCommand("bounty");
        if (pluginCommand != null) {
            pluginCommand.setExecutor(command);
            pluginCommand.setTabCompleter(command);
        }
        getServer().getPluginManager().registerEvents(new EventListener(this), this);

        // Resume an event that was running when the server stopped.
        events.loadState();
        getLogger().info("BountyAssassin enabled.");
    }

    @Override
    public void onDisable() {
        if (events != null) {
            events.shutdown();
        }
    }

    /** Reloads config.yml and re-applies it to the running event (if any). */
    public void reloadAll() {
        reloadConfig();
        this.settings = new Settings(getConfig());
        events.onReload();
    }

    public Settings settings() { return settings; }
    public Messages messages() { return messages; }
    public TrackingService tracking() { return tracking; }
    public BossBarService bossBars() { return bossBars; }
    public IndicatorService indicator() { return indicator; }
    public EventManager events() { return events; }
}
