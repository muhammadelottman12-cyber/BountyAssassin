package me.bountyassassin;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.Locale;

/**
 * Bridges Bukkit events into the {@link EventManager}.
 */
public final class EventListener implements Listener {

    private final BountyPlugin plugin;

    public EventListener(BountyPlugin plugin) {
        this.plugin = plugin;
    }

    private EventManager events() {
        return plugin.events();
    }

    /** Any cause of death: PvP, mobs, fall damage, lava, void, /kill ... */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        if (!events().isRunning() || !events().isActive(victim.getUniqueId())) return;

        // The tracker compass should not drop as loot.
        e.getDrops().removeIf(item -> plugin.indicator().isCompass(item));

        EntityDamageEvent last = victim.getLastDamageCause();
        String cause = last == null
                ? "unknown"
                : last.getCause().name().toLowerCase(Locale.ROOT).replace('_', ' ');
        events().handleDeath(victim, victim.getKiller(), cause);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        events().handleQuit(e.getPlayer());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        events().handleJoin(e.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        events().handleRespawn(e.getPlayer());
    }

    /** Record location immediately after a dimension change so tracking never lags behind. */
    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        if (events().isRunning() && events().isActive(p.getUniqueId())) {
            plugin.tracking().update(p);
        }
    }

    /** Combat tagging for the anti combat-log rule. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        Entity damager = e.getDamager();
        if (damager instanceof Player directAttacker) {
            attacker = directAttacker;
        } else if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Player shooter) {
            attacker = shooter;
        }
        if (attacker == null || attacker.equals(victim)) return;
        events().tagCombat(victim.getUniqueId(), attacker.getUniqueId());
    }
}
