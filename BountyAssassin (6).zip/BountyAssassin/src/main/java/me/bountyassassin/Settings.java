package me.bountyassassin;

import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.GameMode;
import org.bukkit.configuration.file.FileConfiguration;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.Locale;

/**
 * Immutable snapshot of config.yml. A new instance is created on every reload.
 * Only ever used from the main server thread.
 */
public final class Settings {

    // event
    public final long durationSeconds;
    public final int minPlayers;
    public final boolean autoJoinOnline;
    public final int maxParticipants;
    public final boolean allowJoinAfterStart;
    public final boolean allowLeave;
    public final boolean allowRejoin;
    public final int graceSeconds;
    public final int combatTagSeconds;
    public final boolean endWhenOneRemains;
    public final GameMode eliminatedMode; // null = leave alone
    public final GameMode restoreMode;    // null = leave alone

    // boss bar
    public final boolean bossBarEnabled;
    public final String bossBarTitle;
    public final BossBar.Color bossBarColor;
    public final BossBar.Overlay bossBarOverlay;

    // tracking / indicator / compass
    public final int trackingInterval;
    public final boolean showActionBar;
    public final boolean showIndicatorBar;
    public final BossBar.Color indicatorBarColor;
    public final BossBar.Overlay indicatorBarOverlay;
    public final boolean crossDimensionTracking;
    public final int indicatorInterval;
    public final boolean distance3D;
    private final DecimalFormat distanceFormat;
    public final boolean compassEnabled;
    public final boolean compassRemoveOnEnd;
    public final int compassInterval;
    public final boolean compassLastKnownFallback;

    // rewards
    public final boolean healOnComplete;
    public final List<String> bountyCommands;
    public final List<String> winnerCommands;

    public Settings(FileConfiguration c) {
        durationSeconds = Math.max(5L, Math.round(c.getDouble("event.duration-minutes", 120.0) * 60.0));
        minPlayers = Math.max(2, c.getInt("event.min-players-to-start", 2));
        autoJoinOnline = c.getBoolean("event.auto-join-online-players", false);
        maxParticipants = Math.max(0, c.getInt("event.max-participants", 0));
        allowJoinAfterStart = c.getBoolean("event.allow-join-after-start", false);
        allowLeave = c.getBoolean("event.allow-voluntary-leave", true);
        allowRejoin = c.getBoolean("event.allow-rejoin-after-disconnect", true);
        graceSeconds = Math.max(0, c.getInt("event.disconnect-grace-seconds", 300));
        combatTagSeconds = Math.max(0, c.getInt("event.combat-log-seconds", 15));
        endWhenOneRemains = c.getBoolean("event.end-when-one-remains", true);
        eliminatedMode = parseMode(c.getString("event.eliminated-gamemode", "SPECTATOR"), GameMode.SPECTATOR);
        restoreMode = parseMode(c.getString("event.restore-gamemode", "SURVIVAL"), GameMode.SURVIVAL);

        bossBarEnabled = c.getBoolean("bossbar.enabled", true);
        bossBarTitle = c.getString("bossbar.title", "<gold><bold>BOUNTY ASSASSIN EVENT</bold> <yellow>%time% REMAINING");
        bossBarColor = parseColor(c.getString("bossbar.color", "RED"));
        bossBarOverlay = parseOverlay(c.getString("bossbar.style", "PROGRESS"));

        trackingInterval = Math.max(1, c.getInt("tracking.update-interval-ticks", 20));
        String display = c.getString("indicator.display", "BOSSBAR").trim().toUpperCase(Locale.ROOT);
        showActionBar = display.equals("ACTIONBAR") || display.equals("BOTH");
        showIndicatorBar = !display.equals("ACTIONBAR") && !display.equals("NONE");
        indicatorBarColor = parseColor(c.getString("indicator.bossbar-color", "YELLOW"));
        indicatorBarOverlay = parseOverlay(c.getString("indicator.bossbar-style", "PROGRESS"));
        crossDimensionTracking = c.getBoolean("indicator.cross-dimension-tracking", true);
        indicatorInterval = Math.max(1, c.getInt("indicator.update-interval-ticks", 10));
        distance3D = !"2D".equalsIgnoreCase(c.getString("indicator.distance-mode", "3D"));
        DecimalFormat df;
        try {
            df = new DecimalFormat(c.getString("indicator.distance-format", "#,##0"),
                    DecimalFormatSymbols.getInstance(Locale.US));
        } catch (IllegalArgumentException ex) {
            df = new DecimalFormat("#,##0", DecimalFormatSymbols.getInstance(Locale.US));
        }
        distanceFormat = df;

        compassEnabled = c.getBoolean("compass.enabled", true);
        compassRemoveOnEnd = c.getBoolean("compass.remove-on-end", true);
        compassInterval = Math.max(1, c.getInt("compass.update-interval-ticks", 20));
        compassLastKnownFallback = c.getBoolean("compass.last-known-fallback", true);

        healOnComplete = c.getBoolean("rewards.heal-on-bounty-complete", true);
        bountyCommands = c.getStringList("rewards.bounty-commands");
        winnerCommands = c.getStringList("rewards.winner-commands");
    }

    public String formatDistance(double blocks) {
        return distanceFormat.format(blocks);
    }

    private static GameMode parseMode(String raw, GameMode def) {
        if (raw == null) return def;
        String v = raw.trim().toUpperCase(Locale.ROOT);
        if (v.equals("NONE") || v.isEmpty()) return null;
        try {
            return GameMode.valueOf(v);
        } catch (IllegalArgumentException ex) {
            return def;
        }
    }

    private static BossBar.Color parseColor(String raw) {
        try {
            return BossBar.Color.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (Exception ex) {
            return BossBar.Color.RED;
        }
    }

    private static BossBar.Overlay parseOverlay(String raw) {
        String v = raw == null ? "PROGRESS" : raw.trim().toUpperCase(Locale.ROOT).replace("SEGMENTED_", "NOTCHED_");
        if (v.equals("SOLID")) v = "PROGRESS";
        try {
            return BossBar.Overlay.valueOf(v);
        } catch (IllegalArgumentException ex) {
            return BossBar.Overlay.PROGRESS;
        }
    }
}
