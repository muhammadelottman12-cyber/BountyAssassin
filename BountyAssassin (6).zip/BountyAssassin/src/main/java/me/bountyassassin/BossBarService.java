package me.bountyassassin;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * The event countdown boss bar. Only shown to players explicitly passed to {@link #show}.
 */
public final class BossBarService {

    private final BountyPlugin plugin;
    private BossBar bar;

    public BossBarService(BountyPlugin plugin) {
        this.plugin = plugin;
    }

    public void create() {
        destroy();
        Settings s = plugin.settings();
        bar = BossBar.bossBar(Component.empty(), 1.0f, s.bossBarColor, s.bossBarOverlay);
    }

    public boolean exists() {
        return bar != null;
    }

    /** Re-applies colour/style after a config reload. */
    public void applyStyle() {
        if (bar == null) return;
        Settings s = plugin.settings();
        bar.color(s.bossBarColor);
        bar.overlay(s.bossBarOverlay);
    }

    public void show(Player player) {
        if (bar != null && plugin.settings().bossBarEnabled) {
            player.showBossBar(bar);
        }
    }

    public void hide(Player player) {
        if (bar != null) {
            player.hideBossBar(bar);
        }
    }

    public void update(long remainingMillis, long totalMillis, int playersAlive) {
        if (bar == null) return;
        Settings s = plugin.settings();
        bar.name(plugin.messages().parse(s.bossBarTitle,
                "%time%", Messages.formatTime(remainingMillis),
                "%players%", String.valueOf(playersAlive)));
        float progress = totalMillis <= 0 ? 0f : (float) remainingMillis / (float) totalMillis;
        bar.progress(Math.max(0f, Math.min(1f, progress)));
    }

    /** Hides the bar from everyone and discards it. */
    public void destroy() {
        if (bar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.hideBossBar(bar);
            }
            bar = null;
        }
    }
}
