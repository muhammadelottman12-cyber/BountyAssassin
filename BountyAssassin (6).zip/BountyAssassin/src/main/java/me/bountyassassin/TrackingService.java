package me.bountyassassin;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Records the coordinates of active event participants.
 * <ul>
 *   <li>{@link #current} - the most recent location in any dimension (includes world).</li>
 *   <li>{@link #lastIn} - the last known location in a specific world, used by the compass
 *       when the target is in another dimension.</li>
 * </ul>
 * Only participants passed to {@link #updateAll} are tracked, and entries are removed on
 * elimination / event end. Main thread only.
 */
public final class TrackingService {

    private final Map<UUID, Location> current = new HashMap<>();
    private final Map<UUID, Map<UUID, Location>> byWorld = new HashMap<>();

    public void update(Player player) {
        Location loc = player.getLocation();
        UUID id = player.getUniqueId();
        current.put(id, loc);
        byWorld.computeIfAbsent(id, k -> new HashMap<>()).put(loc.getWorld().getUID(), loc.clone());
    }

    public void updateAll(Collection<UUID> participants) {
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) {
                update(p);
            }
        }
    }

    /** Last recorded location in any world, or null. */
    public Location current(UUID id) {
        Location l = current.get(id);
        return l == null ? null : l.clone();
    }

    /** Last recorded location inside the given world (block-aligned), or null. */
    public Location lastIn(UUID id, World world) {
        Map<UUID, Location> m = byWorld.get(id);
        if (m == null) return null;
        Location l = m.get(world.getUID());
        return l == null ? null : l.toBlockLocation();
    }

    public void remove(UUID id) {
        current.remove(id);
        byWorld.remove(id);
    }

    public void clear() {
        current.clear();
        byWorld.clear();
    }
}
