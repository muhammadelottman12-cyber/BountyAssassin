package me.bountyassassin;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * /bounty start|stop|join|leave|status|target|compass|reload|admin
 */
public final class BountyCommand implements CommandExecutor, TabCompleter {

    private static final String PERM_PLAY = "bounty.play";
    private static final String PERM_ADMIN = "bounty.admin";

    private static final List<String> PLAYER_SUBS = List.of("join", "leave", "status", "target", "compass");
    private static final List<String> ADMIN_SUBS = List.of("host", "start", "stop", "kick", "reload", "admin");

    private final BountyPlugin plugin;

    public BountyCommand(BountyPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Messages m = plugin.messages();
        if (command.getName().equalsIgnoreCase("host")) {
            handleHost(sender); // /host and /bountyassassin:host
            return true;
        }
        if (args.length == 0) {
            m.send(sender, "help");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "host" -> handleHost(sender);
            case "start" -> handleStart(sender, args);
            case "stop" -> handleStop(sender);
            case "join" -> handleJoin(sender);
            case "leave" -> handleLeave(sender);
            case "status" -> handleStatus(sender);
            case "target" -> handleTarget(sender);
            case "compass" -> handleCompass(sender);
            case "kick", "remove" -> handleKick(sender, args);
            case "reload" -> handleReload(sender);
            case "admin" -> handleAdmin(sender, args);
            default -> m.send(sender, "help");
        }
        return true;
    }

    // ------------------------------------------------------------------ admin commands

    private void handleStart(CommandSender sender, String[] args) {
        Messages m = plugin.messages();
        if (!require(sender, PERM_ADMIN)) return;
        Double minutes = null;
        if (args.length > 1) {
            try {
                minutes = Double.parseDouble(args[1]);
                if (minutes <= 0) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                m.send(sender, "invalid-number");
                return;
            }
        }
        switch (plugin.events().start(minutes)) {
            case ALREADY_RUNNING -> m.send(sender, "event-already-running");
            case NOT_ENOUGH_PLAYERS -> m.send(sender, "not-enough-players",
                    "%min%", String.valueOf(plugin.settings().minPlayers));
            case OK -> { /* broadcast handled by EventManager */ }
        }
    }

    private void handleHost(CommandSender sender) {
        if (!require(sender, PERM_ADMIN)) return;
        EventManager ev = plugin.events();
        if (ev.isRunning()) {
            plugin.messages().send(sender, "event-already-running");
        } else if (!ev.openLobby()) {
            plugin.messages().send(sender, "host-already-open");
        } else {
            plugin.messages().broadcast("lobby-open");
        }
    }

    private void handleStop(CommandSender sender) {
        if (!require(sender, PERM_ADMIN)) return;
        if (!plugin.events().isRunning()) {
            if (plugin.events().closeLobby()) {
                plugin.messages().broadcast("lobby-closed");
            } else {
                plugin.messages().send(sender, "event-not-running");
            }
            return;
        }
        plugin.events().end(EventManager.EndReason.ADMIN_STOP);
    }

    private void handleKick(CommandSender sender, String[] args) {
        if (!require(sender, PERM_ADMIN)) return;
        Messages m = plugin.messages();
        if (args.length < 2) {
            m.send(sender, "kick-usage");
            return;
        }
        UUID id = plugin.events().findParticipant(args[1]);
        if (id == null || !plugin.events().adminEliminate(id)) {
            m.send(sender, "kick-not-found");
            return;
        }
        m.send(sender, "kick-done", "%player%", plugin.events().nameOf(id));
    }

    private void handleReload(CommandSender sender) {
        if (!require(sender, PERM_ADMIN)) return;
        plugin.reloadAll();
        plugin.messages().send(sender, "reload-done");
    }

    private void handleAdmin(CommandSender sender, String[] args) {
        if (!require(sender, PERM_ADMIN)) return;
        Messages m = plugin.messages();
        EventManager ev = plugin.events();

        if (args.length >= 2) {
            String sub = args[1].toLowerCase(Locale.ROOT);
            if (sub.equals("eliminate") || sub.equals("reassign")) {
                if (args.length < 3) {
                    m.send(sender, "admin-usage");
                    return;
                }
                UUID id = ev.findParticipant(args[2]);
                boolean ok = id != null && (sub.equals("eliminate") ? ev.adminEliminate(id) : ev.adminReassign(id));
                m.send(sender, ok ? "admin-done" : "admin-no-such-player");
                return;
            }
            m.send(sender, "admin-usage");
            return;
        }

        int online = 0;
        for (UUID id : ev.activeSnapshot()) {
            if (ev.isOnline(id)) online++;
        }
        m.send(sender, "admin-header",
                "%state%", ev.getState().name(),
                "%remaining%", Messages.formatTime(ev.remainingMillis()),
                "%active%", String.valueOf(ev.activeCount()),
                "%online%", String.valueOf(online),
                "%eliminated%", String.valueOf(ev.eliminatedCount()));

        for (UUID id : ev.activeSnapshot()) {
            Location loc = plugin.tracking().current(id);
            UUID targetId = ev.getTarget(id);
            m.send(sender, "admin-player",
                    "%player%", ev.nameOf(id),
                    "%status%", ev.isOnline(id) ? "online" : "offline",
                    "%world%", loc == null || loc.getWorld() == null ? "unknown" : loc.getWorld().getName(),
                    "%x%", loc == null ? "?" : String.valueOf(loc.getBlockX()),
                    "%y%", loc == null ? "?" : String.valueOf(loc.getBlockY()),
                    "%z%", loc == null ? "?" : String.valueOf(loc.getBlockZ()),
                    "%target%", targetId == null ? "none" : ev.nameOf(targetId),
                    "%kills%", String.valueOf(ev.completedCount(id)));
        }
    }

    // ------------------------------------------------------------------ player commands

    private void handleJoin(CommandSender sender) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        Messages m = plugin.messages();
        switch (plugin.events().join(p)) {
            case OK -> m.send(p, "join-ok", "%count%", String.valueOf(plugin.events().activeCount()));
            case ALREADY -> m.send(p, "join-already");
            case ELIMINATED -> m.send(p, "join-eliminated");
            case CLOSED -> m.send(p, "join-closed");
            case FULL -> m.send(p, "join-full");
            case NOT_OPEN -> m.send(p, "join-not-open");
        }
    }

    private void handleLeave(CommandSender sender) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        Messages m = plugin.messages();
        switch (plugin.events().leave(p)) {
            case OK -> m.send(p, "leave-ok");
            case NOT_PARTICIPATING -> m.send(p, "leave-not-participating");
            case NOT_ALLOWED -> m.send(p, "leave-not-allowed");
        }
    }

    private void handleStatus(CommandSender sender) {
        Messages m = plugin.messages();
        EventManager ev = plugin.events();
        if (!ev.isRunning()) {
            m.send(sender, ev.isLobbyOpen() ? "status-idle" : "status-closed",
                    "%count%", String.valueOf(ev.lobbyCount()));
            return;
        }
        m.send(sender, "status-running",
                "%time%", Messages.formatTime(ev.remainingMillis()),
                "%active%", String.valueOf(ev.activeCount()),
                "%eliminated%", String.valueOf(ev.eliminatedCount()));
        if (sender instanceof Player p && ev.isActive(p.getUniqueId())) {
            UUID t = ev.getTarget(p.getUniqueId());
            m.send(p, "status-self",
                    "%target%", t == null ? "none" : ev.nameOf(t),
                    "%kills%", String.valueOf(ev.completedCount(p.getUniqueId())));
        }
    }

    private void handleTarget(CommandSender sender) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        EventManager ev = plugin.events();
        if (!ev.isRunning() || !ev.isActive(p.getUniqueId()) || ev.getTarget(p.getUniqueId()) == null) {
            plugin.messages().send(p, "no-bounty");
            return;
        }
        p.sendMessage(plugin.indicator().buildIndicator(p));
    }

    private void handleCompass(CommandSender sender) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        Messages m = plugin.messages();
        EventManager ev = plugin.events();
        if (!plugin.settings().compassEnabled) {
            m.send(p, "compass-disabled");
        } else if (!ev.isRunning() || !ev.isActive(p.getUniqueId())) {
            m.send(p, "no-bounty");
        } else if (plugin.indicator().giveCompass(p)) {
            m.send(p, "compass-given");
        } else {
            m.send(p, "compass-have");
        }
    }

    // ------------------------------------------------------------------ helpers

    private boolean require(CommandSender sender, String permission) {
        if (sender.hasPermission(permission)) return true;
        plugin.messages().send(sender, "no-permission");
        return false;
    }

    private Player requirePlayer(CommandSender sender) {
        if (!(sender instanceof Player p)) {
            plugin.messages().send(sender, "players-only");
            return null;
        }
        // No permission needed: every player can join, leave, check status, etc.
        return p;
    }

    // ------------------------------------------------------------------ tab completion

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            {
                for (String s : PLAYER_SUBS) if (s.startsWith(prefix)) out.add(s);
            }
            if (sender.hasPermission(PERM_ADMIN)) {
                for (String s : ADMIN_SUBS) if (s.startsWith(prefix)) out.add(s);
            }
        } else if (sender.hasPermission(PERM_ADMIN)) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (args.length == 2 && sub.equals("start")) {
                for (String s : List.of("30", "60", "120")) if (s.startsWith(args[1])) out.add(s);
            } else if (args.length == 2 && sub.equals("admin")) {
                for (String s : List.of("eliminate", "reassign")) if (s.startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(s);
            } else if (args.length == 2 && (sub.equals("kick") || sub.equals("remove"))) {
                out.addAll(plugin.events().participantNames(args[1]));
            } else if (args.length == 3 && sub.equals("admin")) {
                out.addAll(plugin.events().participantNames(args[2]));
            }
        }
        return out;
    }
}
