package me.bountyassassin;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.CompassMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * Bounty target indicator (boss bar under the timer, and/or action bar) and the compass-style tracker.
 */
public final class IndicatorService {

    private final BountyPlugin plugin;
    private final NamespacedKey compassKey;
    private final Map<UUID, BossBar> bars = new HashMap<>(); // per-player "bounty + distance" bar

    public IndicatorService(BountyPlugin plugin) {
        this.plugin = plugin;
        this.compassKey = new NamespacedKey(plugin, "bounty_compass");
    }

    // ------------------------------------------------------------------ indicator

    /** Builds the "Current Bounty / Distance" line for a hunter. */
    public Component buildIndicator(Player hunter) {
        EventManager ev = plugin.events();
        Messages m = plugin.messages();
        Settings s = plugin.settings();

        UUID targetId = ev.getTarget(hunter.getUniqueId());
        if (targetId == null) {
            return m.get("indicator-no-target");
        }
        String name = ev.nameOf(targetId);
        Player target = Bukkit.getPlayer(targetId);
        if (target == null || !ev.isOnline(targetId)) {
            return m.get("indicator-offline", "%target%", name);
        }
        Location h = hunter.getLocation();
        Location t = target.getLocation();
        String dimension = dimensionName(t.getWorld());
        if (!Objects.equals(h.getWorld(), t.getWorld())) {
            // Overworld <-> Nether: convert coordinates (1:8) and show an approximate distance.
            Location converted = s.crossDimensionTracking ? convert(t, h.getWorld(), h.getY()) : null;
            if (converted != null) {
                double cx = h.getX() - converted.getX();
                double cz = h.getZ() - converted.getZ();
                return m.get("indicator-cross-dimension", "%target%", name,
                        "%distance%", s.formatDistance(Math.sqrt(cx * cx + cz * cz)),
                        "%dimension%", dimension);
            }
            return m.get("indicator-other-dimension", "%target%", name, "%dimension%", dimension);
        }
        double dx = h.getX() - t.getX();
        double dz = h.getZ() - t.getZ();
        double dy = h.getY() - t.getY();
        double distance = s.distance3D
                ? Math.sqrt(dx * dx + dy * dy + dz * dz)
                : Math.sqrt(dx * dx + dz * dz);
        return m.get("indicator-format", "%target%", name,
                "%distance%", s.formatDistance(distance), "%dimension%", dimension);
    }

    /** Updates the boss bar and/or action bar for one hunter right now. */
    public void sendIndicator(Player hunter) {
        Settings s = plugin.settings();
        Component line = buildIndicator(hunter);
        if (s.showActionBar) {
            hunter.sendActionBar(line);
        }
        if (s.showIndicatorBar) {
            UUID id = hunter.getUniqueId();
            BossBar bar = bars.get(id);
            if (bar == null) {
                // Shown after the timer bar, so it appears directly underneath it.
                bar = BossBar.bossBar(line, 1.0f, s.indicatorBarColor, s.indicatorBarOverlay);
                bars.put(id, bar);
                hunter.showBossBar(bar);
            } else {
                bar.name(line);
                bar.color(s.indicatorBarColor);
                bar.overlay(s.indicatorBarOverlay);
            }
        }
    }

    /** Scheduled: refreshes the indicator for every online participant. */
    public void tickIndicator() {
        Settings s = plugin.settings();
        if (!s.showIndicatorBar && !bars.isEmpty()) {
            clearAll(); // display mode changed on reload
        }
        if (!s.showActionBar && !s.showIndicatorBar) return;
        for (UUID id : plugin.events().activeSnapshot()) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !plugin.events().isOnline(id)) continue;
            sendIndicator(p);
        }
    }

    /** Removes one player's indicator bar (elimination, disconnect, event end). */
    public void clearIndicator(UUID id) {
        BossBar bar = bars.remove(id);
        if (bar != null) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.hideBossBar(bar);
        }
    }

    public void clearAll() {
        for (UUID id : new java.util.ArrayList<>(bars.keySet())) {
            clearIndicator(id);
        }
        bars.clear();
    }

    /**
     * Converts a location between Overworld and Nether coordinates (1:8).
     * Returns null for any other dimension pair (e.g. The End), where no conversion exists.
     */
    private Location convert(Location from, World to, double y) {
        World fromWorld = from.getWorld();
        if (fromWorld == null || to == null) return null;
        World.Environment f = fromWorld.getEnvironment();
        World.Environment t = to.getEnvironment();
        double factor;
        if (f == World.Environment.NORMAL && t == World.Environment.NETHER) {
            factor = 1.0 / 8.0;
        } else if (f == World.Environment.NETHER && t == World.Environment.NORMAL) {
            factor = 8.0;
        } else {
            return null;
        }
        return new Location(to, from.getX() * factor, y, from.getZ() * factor);
    }

    public String dimensionName(World world) {
        Messages m = plugin.messages();
        if (world == null) return "unknown";
        return switch (world.getEnvironment()) {
            case NORMAL -> m.raw("dimension-overworld");
            case NETHER -> m.raw("dimension-nether");
            case THE_END -> m.raw("dimension-end");
            default -> world.getName();
        };
    }

    // ------------------------------------------------------------------ compass

    public ItemStack createCompass() {
        Messages m = plugin.messages();
        ItemStack item = new ItemStack(Material.COMPASS);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(m.get("compass-name").decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(m.get("compass-lore").decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(compassKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isCompass(ItemStack item) {
        if (item == null || item.getType() != Material.COMPASS || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(compassKey, PersistentDataType.BYTE);
    }

    public boolean hasCompass(Player player) {
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            if (isCompass(inv.getItem(i))) return true;
        }
        return false;
    }

    /** Gives the tracker compass if enabled and the player has none. Returns true if given. */
    public boolean giveCompass(Player player) {
        if (!plugin.settings().compassEnabled || hasCompass(player)) return false;
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(createCompass());
        for (ItemStack extra : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }
        return true;
    }

    public void removeCompasses(Player player) {
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            if (isCompass(inv.getItem(i))) {
                inv.setItem(i, null);
            }
        }
    }

    /** Scheduled: points every participant's compass at their target. */
    public void tickCompass() {
        if (!plugin.settings().compassEnabled) return;
        for (UUID id : plugin.events().activeSnapshot()) {
            Player p = Bukkit.getPlayer(id);
            if (p == null || !plugin.events().isOnline(id)) continue;

            Location dest = null;
            boolean destComputed = false;
            PlayerInventory inv = p.getInventory();
            for (int i = 0; i < inv.getSize(); i++) {
                ItemStack item = inv.getItem(i);
                if (!isCompass(item)) continue;
                if (!destComputed) {
                    dest = compassDestination(p);
                    destComputed = true;
                }
                if (!(item.getItemMeta() instanceof CompassMeta meta)) continue;
                if (sameBlock(meta.getLodestone(), dest)) continue;
                meta.setLodestoneTracked(false); // no real lodestone block required
                meta.setLodestone(dest);         // null makes the needle spin
                item.setItemMeta(meta);
                inv.setItem(i, item);
            }
        }
    }

    private Location compassDestination(Player hunter) {
        EventManager ev = plugin.events();
        UUID targetId = ev.getTarget(hunter.getUniqueId());
        if (targetId == null) return null;
        Player target = Bukkit.getPlayer(targetId);
        if (target != null && ev.isOnline(targetId) && target.getWorld().equals(hunter.getWorld())) {
            return target.getLocation().toBlockLocation();
        }
        if (target != null && ev.isOnline(targetId) && plugin.settings().crossDimensionTracking) {
            Location converted = convert(target.getLocation(), hunter.getWorld(), hunter.getLocation().getY());
            if (converted != null) {
                return converted.toBlockLocation();
            }
        }
        if (plugin.settings().compassLastKnownFallback) {
            return plugin.tracking().lastIn(targetId, hunter.getWorld());
        }
        return null;
    }

    private static boolean sameBlock(Location a, Location b) {
        if (a == null || b == null) return a == null && b == null;
        if (a.getWorld() == null || b.getWorld() == null) return false;
        return a.getWorld().equals(b.getWorld())
                && a.getBlockX() == b.getBlockX()
                && a.getBlockY() == b.getBlockY()
                && a.getBlockZ() == b.getBlockZ();
    }
}
