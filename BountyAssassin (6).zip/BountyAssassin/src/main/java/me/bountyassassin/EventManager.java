package me.bountyassassin;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Owns all event state: participants, eliminations, bounty assignments, timer and persistence.
 * Everything runs on the main server thread.
 *
 * State model:
 *  - IDLE:    {@link #active} holds players who registered with /bounty join (lobby).
 *  - RUNNING: {@link #active} = alive participants, {@link #eliminated} = out until next event.
 */
public final class EventManager {

    public enum State { IDLE, RUNNING }
    public enum StartResult { OK, ALREADY_RUNNING, NOT_ENOUGH_PLAYERS }
    public enum JoinResult { OK, ALREADY, ELIMINATED, CLOSED, FULL, NOT_OPEN }
    public enum LeaveResult { OK, NOT_PARTICIPATING, NOT_ALLOWED }
    public enum EndReason { TIME_UP, LAST_STANDING, ADMIN_STOP, NO_PLAYERS }

    private final BountyPlugin plugin;
    private final Random random = new Random();

    private State state = State.IDLE;
    private boolean lobbyOpen = false; // admin must run /bountyassassin:host before players can join
    private final Set<UUID> active = new LinkedHashSet<>();
    private final Set<UUID> eliminated = new LinkedHashSet<>();
    private final Map<UUID, UUID> bounties = new HashMap<>();        // hunter -> target
    private final Map<UUID, UUID> previousTargets = new HashMap<>(); // hunter -> last assigned target
    private final Map<UUID, String> names = new HashMap<>();
    private final Map<UUID, Integer> completed = new HashMap<>();    // bounties completed this event
    private final Set<UUID> quitting = new HashSet<>();              // players mid-disconnect
    private final Map<UUID, Long> lastCombat = new HashMap<>();
    private final Map<UUID, BukkitTask> graceTasks = new HashMap<>();

    // Things to clean up the next time an offline player joins (after the event ended).
    private final Set<UUID> pendingModeRestore = new HashSet<>();
    private final Set<UUID> pendingCompassCleanup = new HashSet<>();

    private final List<BukkitTask> tasks = new ArrayList<>();
    private long endAtMillis;
    private long totalMillis;
    private int initialParticipants;
    private File dataFile;

    public EventManager(BountyPlugin plugin) {
        this.plugin = plugin;
    }

    // ================================================================== queries

    public boolean isRunning() { return state == State.RUNNING; }
    public State getState() { return state; }
    public boolean isActive(UUID id) { return active.contains(id); }
    public boolean isEliminated(UUID id) { return eliminated.contains(id); }
    public int activeCount() { return active.size(); }
    public int eliminatedCount() { return eliminated.size(); }
    public UUID getTarget(UUID hunter) { return bounties.get(hunter); }
    public int completedCount(UUID id) { return completed.getOrDefault(id, 0); }
    public List<UUID> activeSnapshot() { return new ArrayList<>(active); }

    public long remainingMillis() {
        return state == State.RUNNING ? Math.max(0L, endAtMillis - System.currentTimeMillis()) : 0L;
    }

    /** True if the player is on the server and not in the middle of disconnecting. */
    public boolean isOnline(UUID id) {
        Player p = Bukkit.getPlayer(id);
        return p != null && p.isOnline() && !quitting.contains(id);
    }

    public String nameOf(UUID id) {
        String n = names.get(id);
        if (n != null) return n;
        String off = Bukkit.getOfflinePlayer(id).getName();
        return off != null ? off : "Unknown";
    }

    /** Finds a participant (active or eliminated) by name, case-insensitive. */
    public UUID findParticipant(String name) {
        for (UUID id : active) {
            if (nameOf(id).equalsIgnoreCase(name)) return id;
        }
        for (UUID id : eliminated) {
            if (nameOf(id).equalsIgnoreCase(name)) return id;
        }
        return null;
    }

    // ================================================================== lifecycle

    public StartResult start(Double minutesOverride) {
        if (state == State.RUNNING) return StartResult.ALREADY_RUNNING;
        Settings s = plugin.settings();

        if (s.autoJoinOnline) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (active.contains(p.getUniqueId())) continue;
                if (s.maxParticipants > 0 && active.size() >= s.maxParticipants) break;
                active.add(p.getUniqueId());
                names.put(p.getUniqueId(), p.getName());
            }
        }
        active.removeIf(id -> !isOnline(id));
        if (active.size() < s.minPlayers) return StartResult.NOT_ENOUGH_PLAYERS;

        eliminated.clear();
        bounties.clear();
        previousTargets.clear();
        completed.clear();
        lastCombat.clear();
        quitting.clear();
        cancelAllGrace();
        plugin.tracking().clear();

        long seconds = minutesOverride != null
                ? Math.max(5L, Math.round(minutesOverride * 60.0))
                : s.durationSeconds;
        totalMillis = seconds * 1000L;
        endAtMillis = System.currentTimeMillis() + totalMillis;
        initialParticipants = active.size();
        state = State.RUNNING;
        lobbyOpen = false;

        plugin.messages().broadcast("event-start",
                "%time%", Messages.formatTime(totalMillis),
                "%players%", String.valueOf(active.size()));

        plugin.bossBars().create();
        for (UUID id : new ArrayList<>(active)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            names.put(id, p.getName());
            plugin.bossBars().show(p);
            plugin.indicator().giveCompass(p);
            plugin.messages().play(p, "event-start");
        }
        plugin.bossBars().update(totalMillis, totalMillis, active.size());

        List<UUID> order = new ArrayList<>(active);
        Collections.shuffle(order, random);
        // Random cycle: each player hunts the next one in the shuffled list, so every
        // player is targeted by exactly one hunter and nobody gets themselves.
        for (int i = 0; i < order.size(); i++) {
            setBounty(order.get(i), order.get((i + 1) % order.size()));
        }

        plugin.tracking().updateAll(active);
        startTasks();
        save();
        return StartResult.OK;
    }

    /** Ends the event, announces results, cleans up and resets all event data. */
    public void end(EndReason reason) {
        if (state != State.RUNNING) return;
        state = State.IDLE;
        lobbyOpen = false;
        stopTasks();
        Settings s = plugin.settings();
        Messages m = plugin.messages();

        List<UUID> survivors = new ArrayList<>(active);
        List<String> survivorNames = survivors.stream().map(this::nameOf).collect(Collectors.toList());

        switch (reason) {
            case ADMIN_STOP -> m.broadcast("event-stopped");
            case NO_PLAYERS -> m.broadcast("event-end-nobody");
            case LAST_STANDING, TIME_UP -> {
                if (survivors.isEmpty()) {
                    m.broadcast("event-end-nobody");
                } else if (survivors.size() == 1) {
                    m.broadcast("event-end-winner", "%player%", survivorNames.get(0));
                } else {
                    m.broadcast("event-end-survivors", "%players%", String.join(", ", survivorNames));
                }
            }
        }

        if (reason != EndReason.ADMIN_STOP && !completed.isEmpty()) {
            Map.Entry<UUID, Integer> top = null;
            for (Map.Entry<UUID, Integer> e : completed.entrySet()) {
                if (top == null || e.getValue() > top.getValue()) top = e;
            }
            if (top != null) {
                m.broadcast("event-top-hunter", "%player%", nameOf(top.getKey()),
                        "%count%", String.valueOf(top.getValue()));
            }
        }

        if (reason != EndReason.ADMIN_STOP) {
            for (String winner : survivorNames) {
                for (String cmd : s.winnerCommands) {
                    runConsole(cmd.replace("%player%", winner));
                }
            }
        }

        // Clean up every participant (online now, or on next join).
        Set<UUID> everyone = new LinkedHashSet<>(active);
        everyone.addAll(eliminated);
        for (UUID id : everyone) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) {
                plugin.bossBars().hide(p);
                p.sendActionBar(Component.empty());
                if (s.compassRemoveOnEnd) plugin.indicator().removeCompasses(p);
                if (pendingModeRestore.remove(id) && s.restoreMode != null) {
                    p.setGameMode(s.restoreMode);
                }
                if (reason != EndReason.ADMIN_STOP) m.play(p, "event-end");
            } else if (s.compassRemoveOnEnd) {
                pendingCompassCleanup.add(id);
            }
        }
        plugin.bossBars().destroy();
        plugin.indicator().clearAll();
        cancelAllGrace();

        active.clear();
        eliminated.clear();
        bounties.clear();
        previousTargets.clear();
        completed.clear();
        lastCombat.clear();
        quitting.clear();
        plugin.tracking().clear();
        initialParticipants = 0;
        save();
    }

    public void shutdown() {
        save();
        plugin.indicator().clearAll();
        stopTasks();
        cancelAllGrace();
        plugin.bossBars().destroy();
    }

    public void onReload() {
        if (state == State.RUNNING) {
            plugin.bossBars().applyStyle();
            startTasks(); // pick up new intervals
        }
    }

    // ================================================================== join / leave

    public JoinResult join(Player p) {
        UUID id = p.getUniqueId();
        Settings s = plugin.settings();
        if (active.contains(id)) return JoinResult.ALREADY;
        if (state == State.IDLE && !lobbyOpen) return JoinResult.NOT_OPEN;
        if (state == State.RUNNING) {
            if (eliminated.contains(id)) return JoinResult.ELIMINATED;
            if (!s.allowJoinAfterStart) return JoinResult.CLOSED;
        }
        if (s.maxParticipants > 0 && active.size() >= s.maxParticipants) return JoinResult.FULL;

        active.add(id);
        names.put(id, p.getName());

        if (state == State.RUNNING) {
            plugin.bossBars().show(p);
            plugin.indicator().giveCompass(p);
            plugin.tracking().update(p);
            assignBounty(id, true);
            assignMissing();
            save();
        }
        return JoinResult.OK;
    }

    public LeaveResult leave(Player p) {
        UUID id = p.getUniqueId();
        if (!active.contains(id)) return LeaveResult.NOT_PARTICIPATING;
        if (state == State.IDLE) {
            active.remove(id);
            return LeaveResult.OK;
        }
        if (!plugin.settings().allowLeave) return LeaveResult.NOT_ALLOWED;
        eliminate(id, "eliminated-left", "left the event", false);
        checkEnd();
        return LeaveResult.OK;
    }

    /** Admin removal: takes someone out of the lobby, or eliminates them from a running event. */
    public boolean adminEliminate(UUID id) {
        if (!active.contains(id)) return false;
        if (state == State.IDLE) {
            active.remove(id);
            Player p = Bukkit.getPlayer(id);
            if (p != null) plugin.messages().send(p, "removed-from-lobby");
            return true;
        }
        eliminate(id, "eliminated-admin", "removed by an administrator", true);
        checkEnd();
        return true;
    }

    public boolean adminReassign(UUID id) {
        if (state != State.RUNNING || !active.contains(id)) return false;
        assignBounty(id, true);
        return true;
    }

    public int lobbyCount() { return active.size(); }

    public boolean isLobbyOpen() { return state == State.IDLE && lobbyOpen; }

    /** Opens joining. Returns false if an event is running or the lobby is already open. */
    public boolean openLobby() {
        if (state == State.RUNNING || lobbyOpen) return false;
        lobbyOpen = true;
        return true;
    }

    /** Closes the lobby and clears registrations (event not started). Returns false if not open. */
    public boolean closeLobby() {
        if (state == State.RUNNING || !lobbyOpen) return false;
        lobbyOpen = false;
        active.clear();
        return true;
    }

    // ================================================================== bounty logic

    private boolean isValidTarget(UUID hunter, UUID target) {
        return !target.equals(hunter) && active.contains(target) && isOnline(target);
    }

    /**
     * Assigns a random eligible target (never self, never offline/eliminated; avoids repeating the
     * previous target when another choice exists).
     */
    private void assignBounty(UUID hunter, boolean notifyIfNone) {
        List<UUID> candidates = new ArrayList<>();
        for (UUID id : active) {
            if (isValidTarget(hunter, id)) candidates.add(id);
        }
        Player hunterPlayer = Bukkit.getPlayer(hunter);

        if (candidates.isEmpty()) {
            bounties.remove(hunter);
            if (hunterPlayer != null && notifyIfNone) {
                plugin.messages().send(hunterPlayer, "no-target-available");
            }
            return;
        }

        // Prefer targets that nobody else is currently hunting, so two players
        // only share a target when there is no other option left.
        Set<UUID> taken = new HashSet<>();
        for (Map.Entry<UUID, UUID> e : bounties.entrySet()) {
            if (!e.getKey().equals(hunter)) taken.add(e.getValue());
        }
        List<UUID> pool = new ArrayList<>();
        for (UUID id : candidates) {
            if (!taken.contains(id)) pool.add(id);
        }
        if (pool.isEmpty()) {
            pool = new ArrayList<>(candidates);
        }
        UUID previous = previousTargets.get(hunter);
        if (previous != null && pool.size() > 1) {
            pool.remove(previous);
        }
        setBounty(hunter, pool.get(random.nextInt(pool.size())));
    }

    /** Stores the assignment and notifies the hunter. */
    private void setBounty(UUID hunter, UUID chosen) {
        Player hunterPlayer = Bukkit.getPlayer(hunter);
        bounties.put(hunter, chosen);
        previousTargets.put(hunter, chosen);

        if (hunterPlayer != null && isOnline(hunter)) {
            plugin.messages().send(hunterPlayer, "new-bounty", "%target%", nameOf(chosen));
            plugin.messages().play(hunterPlayer, "new-bounty");
            plugin.indicator().sendIndicator(hunterPlayer); // immediate update
        }
    }

    /** Gives a target to every online participant that currently has none. */
    private void assignMissing() {
        for (UUID hunter : new ArrayList<>(active)) {
            if (isOnline(hunter) && !bounties.containsKey(hunter)) {
                assignBounty(hunter, false);
            }
        }
    }

    /** Re-rolls any bounty whose target became invalid (offline, eliminated, ...). */
    private void validateBounties() {
        for (UUID hunter : new ArrayList<>(active)) {
            if (!isOnline(hunter)) continue;
            UUID target = bounties.get(hunter);
            if (target != null && !isValidTarget(hunter, target)) {
                assignBounty(hunter, true);
            }
        }
    }

    private void reassignHunters(UUID oldTarget) {
        for (UUID hunter : new ArrayList<>(bounties.keySet())) {
            if (oldTarget.equals(bounties.get(hunter))) {
                assignBounty(hunter, true);
            }
        }
    }

    // ================================================================== elimination

    private void eliminate(UUID id, String messageKey, String cause, boolean spectator, String... extra) {
        if (state != State.RUNNING || !active.remove(id)) return;
        eliminated.add(id);
        cancelGrace(id);
        bounties.remove(id);
        previousTargets.remove(id);
        lastCombat.remove(id);
        plugin.tracking().remove(id);
        plugin.indicator().clearIndicator(id);

        Settings s = plugin.settings();
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            plugin.bossBars().hide(p);
            plugin.indicator().removeCompasses(p);
            p.sendActionBar(Component.empty());
            plugin.messages().play(p, "eliminated");
        }
        if (spectator && s.eliminatedMode != null) {
            pendingModeRestore.add(id);
            if (p != null && !p.isDead()) {
                p.setGameMode(s.eliminatedMode); // dead players are handled on respawn
            }
        }

        String[] base = {"%player%", nameOf(id), "%cause%", cause, "%remaining%", String.valueOf(active.size())};
        String[] all = new String[base.length + extra.length];
        System.arraycopy(base, 0, all, 0, base.length);
        System.arraycopy(extra, 0, all, base.length, extra.length);
        plugin.messages().broadcast(messageKey, all);

        // Anyone hunting this player needs a new target.
        reassignHunters(id);
        save();
    }

    /** Called for every participant death (PvP, environment, anything). */
    public void handleDeath(Player victim, Player killer, String cause) {
        if (state != State.RUNNING) return;
        UUID vid = victim.getUniqueId();
        if (!active.contains(vid)) return;

        UUID kid = killer != null ? killer.getUniqueId() : null;
        boolean bountyKill = kid != null && active.contains(kid) && vid.equals(bounties.get(kid));

        if (bountyKill) {
            bounties.remove(kid); // so the generic reassign doesn't touch the killer
            completed.merge(kid, 1, Integer::sum);
            eliminate(vid, "bounty-completed", cause, true,
                    "%killer%", killer.getName(), "%victim%", victim.getName());
            reward(killer);
            plugin.messages().play(killer, "bounty-completed");
            assignBounty(kid, true);
        } else if (killer != null) {
            eliminate(vid, "eliminated-by-player", cause, true, "%killer%", killer.getName());
        } else {
            eliminate(vid, "eliminated-death", cause, true);
        }
        checkEnd();
    }

    @SuppressWarnings("deprecation")
    private void reward(Player killer) {
        Settings s = plugin.settings();
        if (s.healOnComplete) {
            killer.setHealth(killer.getMaxHealth());
            killer.setFoodLevel(20);
            killer.setSaturation(20f);
        }
        for (String cmd : s.bountyCommands) {
            runConsole(cmd.replace("%player%", killer.getName()));
        }
    }

    private void runConsole(String command) {
        if (command == null || command.isBlank()) return;
        try {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command.startsWith("/") ? command.substring(1) : command);
        } catch (Exception ex) {
            plugin.getLogger().warning("Command failed: " + command + " (" + ex.getMessage() + ")");
        }
    }

    private void checkEnd() {
        if (state != State.RUNNING) return;
        if (plugin.settings().endWhenOneRemains && initialParticipants >= 2 && active.size() <= 1) {
            end(active.isEmpty() ? EndReason.NO_PLAYERS : EndReason.LAST_STANDING);
        }
    }

    // ================================================================== combat / connection

    public void tagCombat(UUID a, UUID b) {
        if (state != State.RUNNING || !active.contains(a) || !active.contains(b)) return;
        long now = System.currentTimeMillis();
        lastCombat.put(a, now);
        lastCombat.put(b, now);
    }

    private boolean isCombatTagged(UUID id) {
        int seconds = plugin.settings().combatTagSeconds;
        if (seconds <= 0) return false;
        Long last = lastCombat.get(id);
        return last != null && System.currentTimeMillis() - last < seconds * 1000L;
    }

    public void handleQuit(Player p) {
        UUID id = p.getUniqueId();
        plugin.bossBars().hide(p);
        plugin.indicator().clearIndicator(id);

        if (state == State.IDLE) {
            active.remove(id); // leave the lobby
            return;
        }
        if (!active.contains(id)) return;
        // Server shutting down: keep everyone in the event; state is persisted in onDisable.
        if (Bukkit.isStopping()) return;

        Settings s = plugin.settings();
        quitting.add(id);

        if (isCombatTagged(id)) {
            eliminate(id, "eliminated-combat-log", "combat logging", true);
            checkEnd();
            return;
        }
        if (!s.allowRejoin) {
            eliminate(id, "eliminated-disconnect", "disconnected", true);
            checkEnd();
            return;
        }

        startGrace(id);
        reassignHunters(id); // nobody may hunt an offline player
        save();
    }

    public void handleJoin(Player p) {
        UUID id = p.getUniqueId();
        quitting.remove(id);
        Settings s = plugin.settings();

        boolean keepEliminatedMode = state == State.RUNNING && eliminated.contains(id);
        if (!keepEliminatedMode) {
            cleanupPending(p);
        }
        if (state == State.IDLE) return;

        if (active.contains(id)) {
            names.put(id, p.getName());
            cancelGrace(id);
            plugin.bossBars().show(p);
            plugin.indicator().giveCompass(p);
            plugin.tracking().update(p);
            plugin.messages().send(p, "welcome-back");
            validateBounties();
            if (!bounties.containsKey(id)) assignBounty(id, true);
            assignMissing();
            save();
        } else if (eliminated.contains(id)) {
            if (s.eliminatedMode != null) p.setGameMode(s.eliminatedMode);
            plugin.messages().send(p, "you-are-eliminated");
        } else {
            plugin.messages().send(p, "event-running-hint");
        }
    }

    public void handleRespawn(Player p) {
        UUID id = p.getUniqueId();
        Settings s = plugin.settings();
        if (state == State.RUNNING && eliminated.contains(id)
                && pendingModeRestore.contains(id) && s.eliminatedMode != null) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (p.isOnline()) p.setGameMode(s.eliminatedMode);
            });
        }
    }

    private void cleanupPending(Player p) {
        UUID id = p.getUniqueId();
        boolean changed = false;
        if (pendingModeRestore.remove(id)) {
            Settings s = plugin.settings();
            if (s.restoreMode != null) p.setGameMode(s.restoreMode);
            changed = true;
        }
        if (pendingCompassCleanup.remove(id)) {
            plugin.indicator().removeCompasses(p);
            changed = true;
        }
        if (changed) save();
    }

    private void startGrace(UUID id) {
        cancelGrace(id);
        int grace = plugin.settings().graceSeconds;
        if (grace <= 0) return; // unlimited
        BukkitTask task = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            graceTasks.remove(id);
            if (state == State.RUNNING && active.contains(id) && !isOnline(id)) {
                eliminate(id, "eliminated-timeout", "away too long", true);
                checkEnd();
            }
        }, grace * 20L);
        graceTasks.put(id, task);
    }

    private void cancelGrace(UUID id) {
        BukkitTask t = graceTasks.remove(id);
        if (t != null) t.cancel();
    }

    private void cancelAllGrace() {
        for (BukkitTask t : graceTasks.values()) t.cancel();
        graceTasks.clear();
    }

    // ================================================================== scheduling

    private void startTasks() {
        stopTasks();
        Settings s = plugin.settings();
        var scheduler = Bukkit.getScheduler();
        tasks.add(scheduler.runTaskTimer(plugin, this::secondTick, 20L, 20L));
        tasks.add(scheduler.runTaskTimer(plugin, () -> plugin.tracking().updateAll(active), 1L, s.trackingInterval));
        tasks.add(scheduler.runTaskTimer(plugin, () -> plugin.indicator().tickIndicator(), 5L, s.indicatorInterval));
        tasks.add(scheduler.runTaskTimer(plugin, () -> plugin.indicator().tickCompass(), 10L, s.compassInterval));
        tasks.add(scheduler.runTaskTimer(plugin, this::save, 1200L, 1200L));
    }

    private void stopTasks() {
        for (BukkitTask t : tasks) t.cancel();
        tasks.clear();
    }

    /** Runs once per second: countdown, boss bar, self-healing bounty validation. */
    private void secondTick() {
        if (state != State.RUNNING) return;
        long remaining = remainingMillis();
        if (remaining <= 0L) {
            end(EndReason.TIME_UP);
            return;
        }
        validateBounties();
        assignMissing();
        plugin.bossBars().update(remaining, totalMillis, active.size());
    }

    // ================================================================== persistence

    public void save() {
        if (dataFile == null) {
            dataFile = new File(plugin.getDataFolder(), "data.yml");
        }
        YamlConfiguration y = new YamlConfiguration();
        y.set("state", state.name());
        if (state == State.RUNNING) {
            y.set("remaining-millis", remainingMillis());
            y.set("total-millis", totalMillis);
            y.set("initial-participants", initialParticipants);
            y.set("active", active.stream().map(UUID::toString).collect(Collectors.toList()));
            y.set("eliminated", eliminated.stream().map(UUID::toString).collect(Collectors.toList()));
            for (Map.Entry<UUID, UUID> e : bounties.entrySet()) {
                y.set("bounties." + e.getKey(), e.getValue().toString());
            }
            for (Map.Entry<UUID, UUID> e : previousTargets.entrySet()) {
                y.set("previous." + e.getKey(), e.getValue().toString());
            }
            for (Map.Entry<UUID, Integer> e : completed.entrySet()) {
                y.set("completed." + e.getKey(), e.getValue());
            }
            Set<UUID> named = new HashSet<>(active);
            named.addAll(eliminated);
            for (UUID id : named) {
                y.set("names." + id, nameOf(id));
            }
        }
        y.set("pending-mode-restore", pendingModeRestore.stream().map(UUID::toString).collect(Collectors.toList()));
        y.set("pending-compass-cleanup", pendingCompassCleanup.stream().map(UUID::toString).collect(Collectors.toList()));
        try {
            plugin.getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save data.yml: " + ex.getMessage());
        }
    }

    /** Restores a running event after a server restart/reload. Called once from onEnable. */
    public void loadState() {
        dataFile = new File(plugin.getDataFolder(), "data.yml");
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);

        readUuids(y.getStringList("pending-mode-restore"), pendingModeRestore);
        readUuids(y.getStringList("pending-compass-cleanup"), pendingCompassCleanup);

        if (!"RUNNING".equals(y.getString("state"))) return;
        long remaining = y.getLong("remaining-millis", 0L);
        if (remaining <= 0L) return;

        totalMillis = Math.max(remaining, y.getLong("total-millis", remaining));
        endAtMillis = System.currentTimeMillis() + remaining; // downtime does not count
        initialParticipants = y.getInt("initial-participants", 0);
        readUuids(y.getStringList("active"), active);
        readUuids(y.getStringList("eliminated"), eliminated);
        readUuidMap(y.getConfigurationSection("bounties"), bounties);
        readUuidMap(y.getConfigurationSection("previous"), previousTargets);

        ConfigurationSection comp = y.getConfigurationSection("completed");
        if (comp != null) {
            for (String key : comp.getKeys(false)) {
                try {
                    completed.put(UUID.fromString(key), comp.getInt(key));
                } catch (IllegalArgumentException ignored) { }
            }
        }
        ConfigurationSection ns = y.getConfigurationSection("names");
        if (ns != null) {
            for (String key : ns.getKeys(false)) {
                try {
                    names.put(UUID.fromString(key), ns.getString(key, "Unknown"));
                } catch (IllegalArgumentException ignored) { }
            }
        }

        state = State.RUNNING;
        plugin.bossBars().create();
        plugin.bossBars().update(remaining, totalMillis, active.size());
        startTasks();
        plugin.getLogger().info("Resumed Bounty Assassin event: " + Messages.formatTime(remaining)
                + " remaining, " + active.size() + " participants alive.");

        // Everyone is offline after a restart: give each a fresh grace period.
        if (plugin.settings().allowRejoin) {
            for (UUID id : new ArrayList<>(active)) {
                if (Bukkit.getPlayer(id) == null) startGrace(id);
            }
        }
        // /reload case: players already online.
        for (Player p : Bukkit.getOnlinePlayers()) {
            handleJoin(p);
        }
    }

    private static void readUuids(List<String> raw, Set<UUID> into) {
        for (String s : raw) {
            try {
                into.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) { }
        }
    }

    private static void readUuidMap(ConfigurationSection sec, Map<UUID, UUID> into) {
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            try {
                into.put(UUID.fromString(key), UUID.fromString(sec.getString(key, "")));
            } catch (IllegalArgumentException ignored) { }
        }
    }

    /** Lower-case helper for tab completion of participant names. */
    public List<String> participantNames(String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (UUID id : active) {
            String n = nameOf(id);
            if (n.toLowerCase(Locale.ROOT).startsWith(p)) out.add(n);
        }
        return out;
    }
}
