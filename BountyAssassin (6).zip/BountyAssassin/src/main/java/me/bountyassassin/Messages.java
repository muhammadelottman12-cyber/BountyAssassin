package me.bountyassassin;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Reads messages from config.yml, applies %placeholders% and renders MiniMessage.
 * Placeholders are passed as alternating key/value varargs: "%player%", "Steve", ...
 */
public final class Messages {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final BountyPlugin plugin;

    public Messages(BountyPlugin plugin) {
        this.plugin = plugin;
    }

    /** Raw (unparsed) message template, or empty string if missing. */
    public String raw(String key) {
        return plugin.getConfig().getString("messages." + key, "");
    }

    /** Renders any template string with placeholders. */
    public Component parse(String template, String... kv) {
        String s = template.replace("%prefix%", raw("prefix"));
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace(kv[i], kv[i + 1]);
        }
        return MM.deserialize(s);
    }

    public Component get(String key, String... kv) {
        String r = raw(key);
        return r.isEmpty() ? Component.empty() : parse(r, kv);
    }

    public void send(CommandSender to, String key, String... kv) {
        String r = raw(key);
        if (r.isEmpty()) return;
        to.sendMessage(parse(r, kv));
    }

    public void broadcast(String key, String... kv) {
        String r = raw(key);
        if (r.isEmpty()) return;
        Bukkit.broadcast(parse(r, kv));
    }

    /** Plays the sound configured under sounds.<key> to the player (if any). */
    public void play(Player player, String key) {
        String id = plugin.getConfig().getString("sounds." + key, "");
        if (id == null || id.isBlank()) return;
        try {
            player.playSound(Sound.sound(Key.key(id.trim()), Sound.Source.MASTER, 1.0f, 1.0f));
        } catch (Exception ignored) {
            // invalid sound id in config - ignore
        }
    }

    /** Formats milliseconds as HH:MM:SS (rounded up to the next second). */
    public static String formatTime(long millis) {
        long totalSeconds = Math.max(0L, (millis + 999L) / 1000L);
        long h = totalSeconds / 3600L;
        long m = (totalSeconds % 3600L) / 60L;
        long s = totalSeconds % 60L;
        return String.format("%02d:%02d:%02d", h, m, s);
    }
}
