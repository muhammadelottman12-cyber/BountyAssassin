# Bounty Assassin Event (Paper plugin)

A PvP elimination event: every participant is assigned another player as a bounty target.
Kill your target and you get a new random one. Die from *anything* and you're out until the next event.

Requires **Paper 1.21+** and **Java 25**.

## Build

```bash
# Maven 3.9+ and JDK 25
mvn clean package
```

The plugin jar is created at `target/BountyAssassin.jar`.

To compile against a newer Paper API, change the `paper-api` version in `pom.xml`
(currently `1.21.11-R0.1-SNAPSHOT`). Keep `api-version: '1.21'` in `plugin.yml`.

## Install

1. Copy `target/BountyAssassin.jar` into your server's `plugins/` folder.
2. Start the server once - `plugins/BountyAssassin/config.yml` is generated.
3. Edit the config if you want, then `/bounty reload`.

## Commands & permissions

| Command | Permission | Description |
|---|---|---|
| `/bountyassassin:host` (or `/bounty host`) | `bounty.admin` | Open the lobby - nobody can join until an admin does this |
| `/bounty join` | `bounty.play` (default: everyone) | Join the event |
| `/bounty leave` | `bounty.play` | Leave (counts as elimination once the event started) |
| `/bounty status` | `bounty.play` | Remaining time, players alive, your target |
| `/bounty target` | `bounty.play` | Your current bounty and distance |
| `/bounty compass` | `bounty.play` | Re-issue your Bounty Tracker compass |
| `/bounty start [minutes]` | `bounty.admin` (default: op) | Start the event (optional duration override) |
| `/bounty kick <player>` | `bounty.admin` | Remove a player from the lobby or eliminate them mid-event |
| `/bounty stop` | `bounty.admin` | Stop the event (no winner) |
| `/bounty reload` | `bounty.admin` | Reload `config.yml` |
| `/bounty admin` | `bounty.admin` | State, time, and every participant's world/coords/target |
| `/bounty admin eliminate <player>` | `bounty.admin` | Remove a participant |
| `/bounty admin reassign <player>` | `bounty.admin` | Re-roll a participant's target |

Aliases: `/bountyassassin`, `/ba`.

### Typical flow

1. An admin runs `/bountyassassin:host`. Then players run `/bounty join` (or set `event.auto-join-online-players: true`).
2. An admin runs `/bounty start`. Default duration is 120 minutes.
3. Everyone gets a target, a countdown boss bar, an action-bar indicator and a tracker compass.

## How it works

- **Bounties** - random, never yourself, never offline/eliminated players, and never the same target
  twice in a row while other options exist. If your target dies, leaves or goes offline you're
  automatically given a new one. A once-per-second validation pass keeps everything consistent.
- **Elimination** - any death (PvP, lava, fall, mobs, `/kill`) eliminates a participant. Eliminated
  players become spectators (configurable) and can't rejoin until the next event.
- **Anti-exploit** - logging out within `combat-log-seconds` of PvP damage eliminates you. Other
  disconnects get `disconnect-grace-seconds` to return (or instant elimination if rejoin is off).
- **Tracking** - participant locations are recorded every `tracking.update-interval-ticks` in every
  dimension. Distance is only shown when you and your target share a dimension; otherwise the
  indicator shows which dimension they're in. The compass points at the target, or at their last
  known location in your dimension.
- **Ending** - timer reaches zero, or only one participant is left. The winner/survivors are
  announced, then boss bars, compasses and all bounty data are cleared.
- **Restarts** - event state is saved to `plugin/BountyAssassin/data.yml` and resumes after a
  restart (server downtime doesn't consume event time; each participant gets a fresh grace period).

## Files

```
pom.xml
src/main/resources/plugin.yml
src/main/resources/config.yml
src/main/java/me/bountyassassin/
  BountyPlugin.java      entry point / wiring
  Settings.java          typed config snapshot
  Messages.java          MiniMessage + placeholders + sounds
  EventManager.java      participants, bounties, elimination, timer, persistence
  TrackingService.java   participant coordinate tracking
  BossBarService.java    countdown boss bar
  IndicatorService.java  action-bar indicator + tracker compass
  EventListener.java     death / join / quit / respawn / damage hooks
  BountyCommand.java     /bounty command + tab completion
```
